# Copyright (c) 2016, Science and Technology Facilities Council
# This software is distributed under a BSD licence. See LICENSE.txt.

"""Stand-alone module for version number which can be imported or executed with
no dependencies.
"""

__version__ = '1.0.0'
