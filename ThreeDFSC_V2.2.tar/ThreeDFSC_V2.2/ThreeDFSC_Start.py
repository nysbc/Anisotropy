#!/usr/bin/env python
### Require Anaconda3

### ============================
### 3D FSC Software Wrapper
### Written by Philip Baldwin
### Edited by Yong Zi Tan and Dmitry Lyumkis
### Downloaded from https://github.com/nysbc/Anisotropy
### 
### See Paper:
### Addressing preferred specimen orientation in single-particle cryo-EM through tilting
### 10.1038/nmeth.4347
###
### Credits:
### 1) UCSF Chimera, especially Tom Goddard
### 2) mrcfile 1.0.0 by Colin Palmer (https://github.com/ccpem/mrcfile)
###
### Version 2.2 (2 July 2017)
### 
### Revisions 
### 1.1 - Added mpl.use('Agg') to allow matplotlib to be used without X-server
###     - Added Sum of Standard Deviation
### 1.2 - Added FSCCutoff Option
### 2.0 - Incorporation of AutoJIT version of 3D FSC for 10x faster processing
### 2.1 - 3D FSC takes MRC files
### 2.2 - Fixed bugs with 3DFSC missing a line in volume, and plotting title error
version = "2.2"
### ============================

#pythonlib
import matplotlib
matplotlib.use('Agg')
from optparse import OptionParser
import os
import sys
from math import sqrt
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import time
start_time = time.time()

#Sub-packages
from ThreeDFSC import ThreeDFSC_ReleaseJul2017
from ThreeDFSC import ThreeDFSC_Analysis_V2

def main():
	parser = OptionParser(usage="usage: %prog [options] filename", version="%prog " + version)
	parser.add_option("--halfmap1", dest="halfmap1", action="store", type="string", help="First half map of 3D reconstruction. MRC format. Can be masked or unmasked.", metavar="HALFMAP1.MRC")
	parser.add_option("--halfmap2", dest="halfmap2", action="store", type="string", help="Second half map of 3D reconstruction. MRC format. Can be masked or unmasked.", metavar="HALFMAP2.MRC")
	parser.add_option("--fullmap", dest="fullmap", action="store", type="string", help="Full map of 3D reconstruction. MRC format. Can be masked or unmasked, can be sharpened or unsharpened.", metavar="FULLMAP.MRC")
	parser.add_option("--apix", dest="apix", action="store", type="float", default=1, help="Angstrom per pixel of 3D map.", metavar="FLOAT")
	parser.add_option("--ThreeDFSC", dest="ThreeDFSC", action="store", type="string", default="3DFSCOutput", help="Name of output 3DFSC map. No file extension required - it will automatically be given a .mrc extension.", metavar="FILENAME")
	parser.add_option("--dthetaInDegrees", dest="dthetaInDegrees", action="store", type="float", default=20, help="Angle of cone to be used for 3D FSC sampling in degrees. Default is 20 degrees.", metavar="FLOAT")
	parser.add_option("--histogram", dest="histogram", action="store", type="string", default="histogram", help="Name of output histogram graph. No file extension required - it will automatically be given a .pdf extension.", metavar="FILENAME")
	#parser.add_option("--histogramdata", dest="histogramdata", action="store", type="string", default="histogramdata", help="Name of raw data for histogram. No file extension required - it will automatically be given a .csv extension.", metavar="FILENAME")
	parser.add_option("--FSCCutoff", dest="FSCCutoff", action="store", type="float", default=0.143, help="FSC cutoff criterion. 0.143 is default.", metavar="FLOAT")
	#parser.add_option("--Anaconda3Path", dest="Anaconda3Path", action="store", type="string", help="Full path for Anaconda 3 Python, if is not the default python used.", default="/gpfs/sw/anaconda/anaconda3/bin/python", metavar="FILEPATH")
	parser.add_option("--ThresholdForSphericity", dest="ThresholdForSphericity", action="store", type="float", default=0.5, help="Threshold value for 3DFSC volume for calculating sphericity. 0.5 is default.", metavar="FLOAT")
	parser.add_option("--HighPassFilter", dest="HighPassFilter", action="store", type="float", default=150.0, help="High pass filter for thresholding in Angstrom. Prevents small dips in directional FSCs at low spatial frequency due to noise from messing up the thresholding step. Decrease if you see a huge wedge missing from your thresholded 3DFSC volume. 150 Angstroms is default.", metavar="FLOAT")
	(options, args) = parser.parse_args()

	print ("Welcome to 3DFSC Program Suite Version %s" % version)
	print ("Downloaded from https://github.com/nysbc/Anisotropy")
	print ("Anaconda 3 is required to run this program, and UCSF Chimera to visualize some outputs. Please install them if they are not present.")
	print ("Please be patient: Program usually finishes in minutes, but can take up to an hour to run for extremely large box sizes.")
	#print (options)
	#print (args)
	#print ("\n")
	
	# Part 01
	print ("\n\033[1;31;40mStep 01: Generating 3DFSC Volume \033[0;37;40m")
	ThreeDFSC_ReleaseJul2017.main(options.halfmap1,options.halfmap2,options.ThreeDFSC,options.apix,options.dthetaInDegrees)
	os.system("cp Results" + options.ThreeDFSC + "/ResEM" + options.ThreeDFSC + "Out.mrc Results" + options.ThreeDFSC + "/" + options.ThreeDFSC + ".mrc")
	print ("3DFSC Results" + options.ThreeDFSC + "/" + options.ThreeDFSC + ".mrc generated.")
	
	# Part 02
	print ("\n\033[1;31;40mStep 02: Generating Analysis Files \033[0;37;40m")
	ThreeDFSC_Analysis_V2.main(options.halfmap1,options.halfmap2,options.fullmap,options.apix,options.ThreeDFSC,options.dthetaInDegrees,options.histogram,options.FSCCutoff,options.ThresholdForSphericity,options.HighPassFilter)
	print ("\n")
	
	print ("Done")
	print ("Results are in the folder Results" + str(options.ThreeDFSC))
	print ("--- %s seconds ---" % (time.time() - start_time))
	print ("Please email pbaldwin@nysbc.org, ytan@nysbc.org and dlyumkis@salk.edu if there are any problems/suggestions. Thank you.")
	
if __name__ == '__main__':
	main()

