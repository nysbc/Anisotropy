#!/usr/bin/env python

### ============================
### 3D FSC Software Package
### Analysis Section
### Written by Yong Zi Tan and Dmitry Lyumkis
### Downloaded from https://github.com/nysbc/Anisotropy
### 
### See Paper:
### Addressing preferred specimen orientation in single-particle cryo-EM through tilting
### 10.1038/nmeth.4347
###
### Credits:
### 1) UCSF Chimera, especially Tom Goddard
### 2) mrcfile 1.0.0 by Colin Palmer (https://github.com/ccpem/mrcfile)
###
### Version 2.0 (27 June 2017)
### 
### Revisions 
### 1.0 - Created analysis program
### 2.0 - Combined with plotting, thresholding and sphericity
### ============================
version = "1.0"

#pythonlib
import matplotlib
matplotlib.use('Agg')
import os
import numpy as np
import mrcfile
import sys
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import scipy.ndimage
import scipy.misc
from math import sqrt, acos, atan2, cos, sin


#Sub-packages
from ThreeDFSC import calculate_sphericity

def cartesian_to_spherical(vector):
	"""Convert the Cartesian vector [x, y, z] to spherical coordinates [r, theta, phi].

	The parameter r is the radial distance, theta is the polar angle, and phi is the azimuth.


	@param vector:  The Cartesian vector [x, y, z].
	@type vector:   numpy rank-1, 3D array
	@return:        The spherical coordinate vector [r, theta, phi].
	@rtype:         numpy rank-1, 3D array
	"""

	# The radial distance.
	r = np.linalg.norm(vector)

	# Unit vector.
	unit = vector / r

	# The polar angle.
	theta = acos(unit[2])

	# The azimuth.
	phi = atan2(unit[1], unit[0])

	# Return the spherical coordinate vector.
	return np.array([r, theta, phi], np.float64)

def spherical_to_cartesian(spherical_vect, cart_vect):
	"""Convert the spherical coordinate vector [r, theta, phi] to the Cartesian vector [x, y, z].

	The parameter r is the radial distance, theta is the polar angle, and phi is the azimuth.


	@param spherical_vect:  The spherical coordinate vector [r, theta, phi].
	@type spherical_vect:   3D array or list
	@param cart_vect:       The Cartesian vector [x, y, z].
	@type cart_vect:        3D array or list
	"""

	# Trig alias.
	sin_theta = sin(spherical_vect[1])

	# The vector.
	cart_vect[0] = spherical_vect[0] * cos(spherical_vect[2]) * sin_theta
	cart_vect[1] = spherical_vect[0] * sin(spherical_vect[2]) * sin_theta
	cart_vect[2] = spherical_vect[0] * cos(spherical_vect[1])

	return cart_vect

def StandardDeviation(input):
	input_num = [float(c) for c in input]
	mean = sum(input_num) / len(input_num)
	diff = [a - mean for a in input_num]
	sq_diff = [b ** 2 for b in diff]
	ssd = sum(sq_diff)
	variance = ssd / (len(input_num) - 1)
	sd = sqrt(variance)
	return sd
	
def Mean(input):
	input_num = [float(c) for c in input]
	mean = sum(input_num) / len(input_num)
	return mean
	
def convert_highpassfilter_to_Fourier_Shells(ThreeDFSC,apix,highpassfilter):

	a = open("Results" + ThreeDFSC + "/ResEM" + ThreeDFSC + "OutglobalFSC.csv","r")
	b = a.readlines()
	b.pop(0)
	
	globalspatialfrequency = []
	globalfsc = []

	for i in b:
		k = (i.strip()).split(",")
		globalspatialfrequency.append(float(k[0]))
		globalfsc.append(float(k[2]))

	for i in range(len(globalspatialfrequency)):
		if ((1.0/globalspatialfrequency[i])*apix) <= highpassfilter:
			highpassfilter_fouriershell = i-1
			break
	
	if highpassfilter_fouriershell < 0:
		highpassfilter_fouriershell = 0

	return highpassfilter_fouriershell
	
def binarize(inmrc, thresholded, thresholdedbinarized, thresh, highpassfilter):
	
	# zoom factor
	# zoom = 2.0
	
	# read MRC
	inputmrc = (mrcfile.open(inmrc)).data
	# inputmrc = scipy.ndimage.interpolation.zoom(inputmrc_raw,zoom) # To overcome the problem of not having decimal indices in python 3
	
	# coordinates
	center = [inputmrc.shape[0]/2,inputmrc.shape[1]/2,inputmrc.shape[2]/2]
	radius = int(inputmrc.shape[0]/2 + 0.5)
		
	# fill up new numpy array
	boxsize = inputmrc.shape[0]
	outarray = np.zeros((boxsize,)*3)
	outarray2 = np.zeros((boxsize,)*3)
	
	for theta in np.arange(1,360,1):
		#print("theta: %d" % (theta))
		for phi in np.arange(1,360,1):
			setrest = False
			for r in range(radius):
				
				# convert polar to cartesian and read mrc
				spherical_vect = [r, theta, phi]
				cart_vect = spherical_to_cartesian(spherical_vect, [0,0,0])
				cart_vect_new = np.add(cart_vect, center)

				x = int(cart_vect_new[0]) 
				y = int(cart_vect_new[1])
				z = int(cart_vect_new[2])
				
				# binarize
				# if setrest is True, everything beyond this radius value should be 0
				if (r > int(highpassfilter)):
					if setrest is False:
						if inputmrc[x][y][z] < float(thresh):
							outarray[x][y][z] = 0
							outarray2[x][y][z] = 0
							setrest = True
							#print "false", r, x, y, z, inputmrc[x][y][z]
							break
						else:
							outarray[x][y][z] = 1 #inputmrc[x][y][z]
							outarray2[x][y][z] = inputmrc[x][y][z]
					else:
						#print "true", r, x, y, z, inputmrc[x][y][z]
						outarray[x][y][z] = 0
						outarray2[x][y][z] = 0
				else:
					outarray[x][y][z] = 1
					outarray2[x][y][z] = inputmrc[x][y][z]
					
	# thresholdedbinarized_resized = scipy.ndimage.interpolation.zoom(outarray,1/zoom)
	mrc_write = mrcfile.new(thresholdedbinarized,overwrite=True)
	mrc_write.set_data(outarray.astype('<f4'))
	mrc_write.close()
	# thresholded_resized = scipy.ndimage.interpolation.zoom(outarray2,1/zoom)
	mrc_write = mrcfile.new(thresholded,overwrite=True)
	mrc_write.set_data(outarray2.astype('<f4'))
	mrc_write.close()

def histogram_sample(inmrc, thresh, highpassfilter):
	
	# read MRC
	inputmrc = (mrcfile.open(inmrc)).data
	
	# coordinates
	center = [inputmrc.shape[0]/2,inputmrc.shape[1]/2,inputmrc.shape[2]/2]
	radius = int(inputmrc.shape[0]/2 + 0.5)
		
	# fill up new numpy array
	boxsize = inputmrc.shape[0]
	outarray = np.zeros((boxsize,)*3)
	outarray2 = np.zeros((boxsize,)*3)
	
	histogram_sampling = np.empty([radius,10*10]) # write out the histogram 1D FSCs
	counter = 0
	
	for theta in np.arange(1,360,36):
		#print("theta: %d" % (theta))
		for phi in np.arange(1,360,36):
			setrest = False
			for r in range(radius):
				
				# convert polar to cartesian and read mrc
				spherical_vect = [r, theta, phi]
				cart_vect = spherical_to_cartesian(spherical_vect, [0,0,0])
				cart_vect_new = np.add(cart_vect, center)

				x = int(cart_vect_new[0])
				y = int(cart_vect_new[1])
				z = int(cart_vect_new[2])
				
				# binarize
				# if setrest is True, everything beyond this radius value should be 0
				if (r > int(highpassfilter)):
					histogram_sampling[r][counter] = inputmrc[x][y][z]
				else:
					histogram_sampling[r][counter] = 1
			counter += 1
			
	return histogram_sampling
	
def HistogramCreation(histogram_sampling,histogram,ThreeDFSC,apix,cutoff,sphericity):
	
	stddev = []
	mean = []
	for i in histogram_sampling:
		stddev.append(StandardDeviation(i))
		mean.append(Mean(i))
	#print (stddev)
	#print (mean)
	
	stdplusone = [mean[a] + stddev[a] for a in range(len(mean))]
	stdminusone = [mean[a] - stddev[a] for a in range(len(mean))]
	
	## Open Global FSC
	
	a = open("Results" + ThreeDFSC + "/ResEM" + ThreeDFSC + "OutglobalFSC.csv","r")
	b = a.readlines()
	b.pop(0)
	
	globalspatialfrequency = []
	globalfsc = []
	
	for i in b:
		k = (i.strip()).split(",")
		globalspatialfrequency.append(float(k[0]))
		globalfsc.append(float(k[2]))
	#print (len(globalspatialfrequency))
	maxrange = max(globalspatialfrequency)
	minrange = min(globalspatialfrequency)
	
	## Calculate Sum of Standard Deviation
	## http://stats.stackexchange.com/questions/25848/how-to-sum-a-standard-deviation
	
	sumofvar = 0
	for a in stddev:
		sumofvar += a ** 2
	sumofstd = sqrt(sumofvar)
	
	#print ("\n\n")
	#print ("Sum of Standard Deviation is %s" % sumofstd)
	#print ("\n\n")
	
	## Histogram
	
	histogramlist = []
	
	for i in range(len(histogram_sampling[0])):
		for j in range(len(histogram_sampling)):
			if float(histogram_sampling[j][i]) < cutoff: ##Changed to 0.5
				break
			else:
				output = globalspatialfrequency[j]
		histogramlist.append(float(output))
	
	#print (histogramlist)
	
	## Plotting

	plt.title("Histogram and Directional FSC Plot for %s \n Sphericity is %f out of 1. \n \n \n \n" % (str(ThreeDFSC),sphericity))
	ax1 = plt.subplot(111)
	ax1.set_xlim([minrange,maxrange])
	n, bins, patches = plt.hist(histogramlist, bins=10, range=(minrange,maxrange))
	ax1.set_ylabel("Percentage of Per Angle FSC (%)", color="#0343df")
	for tl in ax1.get_yticklabels():
		tl.set_color("#0343df")

	ax2 = ax1.twinx()
	ax2.set_ylim([0,1])
	ax2.set_xlim([minrange,maxrange])
	ax2.plot(globalspatialfrequency, globalfsc, linewidth=3, color="#e50000")
	ax2.plot(globalspatialfrequency, stdplusone, linewidth=1, linestyle="--", color="#15b01a")
	ax2.plot(globalspatialfrequency, stdminusone, linewidth=1, linestyle="--", color="#15b01a")
	ax2.plot((minrange,maxrange), (cutoff, cutoff), linestyle="--", color="#929591")
	ax2.set_ylabel("Directional Fourier Shell Correlation", color='#e50000')
	for tl in ax2.get_yticklabels():
		tl.set_color("r")
		
	blue_patch = mpatches.Patch(color="#0343df", label="Histogram of Directional FSC")
	red_solid_line = mlines.Line2D([], [], color="#e50000", linewidth=3, label="Global FSC")
	green_dotted_line = mlines.Line2D([], [], color="#15b01a", linestyle="--", label="$\pm$1 S.D. from Mean of Directional FSC")
	#box = ax1.get_position()
	#ax1.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	#ax2.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
	ax1.legend(handles=[blue_patch, green_dotted_line, red_solid_line],loc='center', bbox_to_anchor=(0.5, 1.1), ncol=2)
	xlabel = ax1.set_xlabel("Spatial Frequency ($\AA^{-1}$)")

	#plt.show()
	plt.savefig("Results" + ThreeDFSC + "/" + histogram + ".pdf", bbox_extra_artists=[xlabel], bbox_inches="tight")
	
	#Flush out plots
	plt.clf()
	plt.cla()
	plt.close()
	
	## Return useful values for ChimeraOutputCreate
	return(1/float(max(histogramlist)),1/float(min(histogramlist)))
	
def ChimeraOutputCreate(ThreeDFSC,apix,maxRes,minRes,fullmap):
	
	## Generate Lineplot.py File
	
	with open("temp.txt", "wt") as fout:
		with open("Results" + str(ThreeDFSC) + "/Chimera/lineplot_template.py", "rt") as fin:
			for line in fin:
				fout.write(line.replace("#==apix==#", str(apix)))
				
	with open("temp2.txt", "wt") as fout:
		with open("temp.txt", "rt") as fin:
			for line in fin:
				fout.write(line.replace("#==maxres==#", str(maxRes)))

	with open("Results" + str(ThreeDFSC) + "/Chimera/lineplot_template.py", "wt") as fout:
		with open("temp2.txt", "rt") as fin:
			for line in fin:
				fout.write(line.replace("#==minres==#", str(minRes)))				
				
	## 3DFSCPlot_Chimera.cmd File
	
	with open("temp.txt", "wt") as fout:
		with open("Results" + str(ThreeDFSC) + "/Chimera/3DFSCPlot_Chimera_Template.cmd", "rt") as fin:
			for line in fin:
				fout.write(line.replace("#===3DFSC====#", str(ThreeDFSC) + ".mrc"))
				
	with open("Results" + str(ThreeDFSC) + "/Chimera/3DFSCPlot_Chimera_Template.cmd", "wt") as fout:
		with open("temp.txt", "rt") as fin:
			for line in fin:
				fout.write(line.replace("#===FullMap====#", str(fullmap)))
				
	## Cleanup
	
	os.system("rm temp.txt")
	os.system("rm temp2.txt")
				
def main(halfmap1,halfmap2,fullmap,apix,ThreeDFSC,dthetaInDegrees,histogram,FSCCutoff,ThresholdForSphericity,HighPassFilter):
	# Part 01
	print ("\n\033[1;31;40mAnalysis Step 01: Generating thresholded and thresholded + binarized maps. \033[0;37;40m")
	print ("These maps can be used to make figures, and are required for calculating sphericity.")
	FourierShellHighPassFilter = convert_highpassfilter_to_Fourier_Shells(ThreeDFSC,apix,HighPassFilter)
	binarize("Results" + ThreeDFSC + "/ResEM" + ThreeDFSC + "Out.mrc", "Results" + ThreeDFSC + "/" + ThreeDFSC + "_Thresholded.mrc", "Results" + ThreeDFSC + "/" + ThreeDFSC + "_ThresholdedBinarized.mrc", ThresholdForSphericity,FourierShellHighPassFilter)
	print ("Results" + ThreeDFSC + "/" + ThreeDFSC + "_Thresholded.mrc and Results" + ThreeDFSC + "/" + ThreeDFSC + "_ThresholdedBinarized.mrc generated.")
	# Part 02
	print ("\n\033[1;31;40mAnalysis Step 02: Calculating sphericity. \033[0;37;40m")
	sphericity = calculate_sphericity.main("Results" + ThreeDFSC + "/" + ThreeDFSC + "_ThresholdedBinarized.mrc",ThresholdForSphericity)
	print ("Sphericity is %f out of 1. 1 represents a perfect sphere." % (sphericity))
	# Part 03
	print ("\n\033[1;31;40mAnalysis Step 03: Generating Histogram. \033[0;37;40m")
	histogram_sampling = histogram_sample("Results" + ThreeDFSC + "/ResEM" + ThreeDFSC + "Out.mrc",ThresholdForSphericity,FourierShellHighPassFilter)
	# Part 04
	maxRes, minRes = HistogramCreation(histogram_sampling,histogram,ThreeDFSC,apix,FSCCutoff,sphericity)
	print ("Results" + ThreeDFSC + "/" + histogram + ".pdf generated.")
	# Part 05
	print ("\n\033[1;31;40mAnalysis Step 04: Generating Output Files for Chimera Viewing of 3DFSC \033[0;37;40m")
	os.system("cp -r " + os.path.realpath(__file__)[:-24] + "Chimera Results" + str(ThreeDFSC) + "/")
	ChimeraOutputCreate(ThreeDFSC,apix,maxRes,minRes,fullmap)
	print ("Results" + str(ThreeDFSC) + "/Chimera/3DFSCPlot_Chimera_Template.cmd and Results" + str(ThreeDFSC) + "/Chimera/lineplot_template.py generated.")
	print ("To view in Chimera, open 3DFSCPlot_Chimera_Template.cmd in Chimera, with lineplot_template.py in the same directory.")
	
if __name__ == '__main__':
	main(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6],sys.argv[7],sys.argv[8],sys.argv[9],sys.argv[10])