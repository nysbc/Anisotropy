#!/usr/bin/env python
# 3D FSC Calculate Sphericity
# By Yong Zi Tan
# 28 June 2017

import math
import numpy
import mrcfile
import sys
from skimage import measure
from scipy.ndimage.filters import gaussian_filter

def main(inmrc, thresh):
	# read MRC
	inputmrc = (mrcfile.open(inmrc)).data
	
	# Gaussian filtering
	# Sigma=1 works well
	blurred = gaussian_filter(inputmrc,sigma=1)
	
	# Find surfaces using marching cube algorithm
	verts, faces, normals, values = measure.marching_cubes_lewiner(blurred,level=thresh)
	
	# Find surface area
	surface_area = measure.mesh_surface_area(verts,faces)
	
	# Find volume
	volume = numpy.sum(inputmrc)
	
	# Calculate sphericity
	sphericity = (((math.pi)**(1/3))*((6*volume)**(2/3)))/(surface_area)
	return sphericity

if __name__ == "__main__":
	inmrc = sys.argv[1] # Should be binarized already
	thresh = sys.argv[2]
	main(inmrc, thresh)



